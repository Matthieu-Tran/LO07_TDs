<nav class="navbar navbar-expand-lg bg-primary fixed-top">

  <div class="container-fluid">
    <a class="navbar-brand" href="#">Matthieu Tran</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link" href="./module_form.php" rel="noreferrer">Exercice 1</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="./cursus_main.php" rel="noreferrer">Exercice Main</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="./cursus_form2.php" rel="noreferrer">Exercice Cursus</a>
        </li>
      </ul>
    </div>
  </div>
</nav>